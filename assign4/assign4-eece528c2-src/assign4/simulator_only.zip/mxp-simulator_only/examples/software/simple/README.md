# Simple Example

This directory contains the simplest example possible for creating a program
that utilizes the Vectorblox MXP.

You can run `make` to build both the c++ example and the c example.
