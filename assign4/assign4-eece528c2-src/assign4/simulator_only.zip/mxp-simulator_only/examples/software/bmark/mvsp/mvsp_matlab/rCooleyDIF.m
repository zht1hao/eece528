function C = rCooleyDIF(k,m)
n = k*m;
C = vL(n,m)* vIF(k,m)* vT(n,m) * vFI(k,m);






