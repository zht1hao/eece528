function IL = vIL(k,n,m)
IL = kron(eye(k),vL(n,m));
