function LI = vLI(n,m,k)
LI = kron(vL(n,m),eye(k));
