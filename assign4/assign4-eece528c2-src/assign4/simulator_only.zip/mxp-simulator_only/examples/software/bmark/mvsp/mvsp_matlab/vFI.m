function FI = vFI(n,m)
FI = kron(vF(n),eye(m));

