Source: https://code.google.com/p/libfixmath/

Minor changes made by Vectorblox Inc.

License: MIT http://opensource.org/licenses/mit-license.php
