/*
 * Word compilation unit for FIR test
 */

#define VBX_TEMPLATE_T VBX_WORDSIZE_DEF
#define TEST_NAME      int32_t_fir_test

#include "fir_test_template.h"
