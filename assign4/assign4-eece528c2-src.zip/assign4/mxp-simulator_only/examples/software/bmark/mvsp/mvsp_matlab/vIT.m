function IT = vIT(k,n,m)
IT = kron(eye(k),vT(n,m));
