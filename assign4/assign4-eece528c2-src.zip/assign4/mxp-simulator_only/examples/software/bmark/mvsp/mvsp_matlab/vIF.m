function IF = vIF(n,m)
IF = kron(eye(n),vF(m));

