function IFI = vIFI(k,n,m)
IFI = kron(eye(k),vFI(n,m));

