function TI = vTI(n,m,k)
TI = kron(vT(n,m),eye(k));
